from screens import login, recipe, recipe_limits
import squish




def reset_notification():
    squish.snooze(0.2)
    test.log("Reset notification function execution")
    login.notification_reset()

def new_create_recipe():
    test.log("Started with creation of new recipe")
    recipe.CreateNewRecipe()
    
def test_limits():
    recipe_limits.limitsTab()
    # recipe_limits.suspectAndRejectTab()
    recipe_limits.globalSuspectEnable()
    # recipe_limits.globalRejectEnable()
    recipe_limits.timeTabEnterValue()

def test_limits_control():
    recipe_limits.limitsTab()
    squish.snooze(0.2)
    recipe_limits.controlTab()
    squish.snooze(0.2)
    recipe_limits.controlEnable()
    squish.snooze(0.2)
    
def main():
    test.log("Enters into main function of weld process")
    
    startApplication("QT_UIController")
    squish.snooze(7)
    new_create_recipe()
    squish.snooze(0.2)
    test_limits_control()

