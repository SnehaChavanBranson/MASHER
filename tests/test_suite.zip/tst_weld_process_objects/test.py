# -*- coding: utf-8 -*-

import names

def main():
    test.log("Hello World")

#weld process tab
recipeTabBar_BransonTabButton_2 = {"checkable": True, "container": recipeLabWindow_recipeTabBar_TabBar, "occurrence": 2, "type": "BransonTabButton", "unnamed": 1, "visible": True}

#pretrigger tab
subrecipeTabBar_BransonTabButton_2 = {"checkable": True, "container": recipeLabWindow_subrecipeTabBar_TabBar, "type": "BransonTabButton", "unnamed": 1, "visible": True}

#enable pretrigger
recipeLabWindow_pretriggerEnableSwitch_BransonSwitch = {"checkable": True, "container": uIController_recipeLabWindow_Item, "id": "pretriggerEnableSwitch", "type": "BransonSwitch", "unnamed": 1, "visible": True}

#pretrigger amplitude
names.recipeLabWindow_PRETRIGGER_AMPLITUDE_Text = {"container": uIController_recipeLabWindow_Item, "text": "PRETRIGGER AMPLITUDE", "type": "Text", "unnamed": 1, "visible": True}

#pretrigger distance
names.recipeLabWindow_PRETRIGGER_DISTANCE_Text = {"container": uIController_recipeLabWindow_Item, "text": "PRETRIGGER DISTANCE", "type": "Text", "unnamed": 1, "visible": True}

#pretrigger time
names.recipeLabWindow_PRETRIGGER_TIME_Text = {"container": uIController_recipeLabWindow_Item, "text": "PRETRIGGER TIME", "type": "Text", "unnamed": 1, "visible": True}

#pretrigger start: time
recipeLabWindow_radioButtonTime_BransonRadioButton = {"checkable": True, "container": uIController_recipeLabWindow_Item, "id": "radioButtonTime", "type": "BransonRadioButton", "unnamed": 1, "visible": True}

#pretrigger start: distance
recipeLabWindow_radioButtonDistance_BransonRadioButton = {"checkable": True, "container": uIController_recipeLabWindow_Item, "id": "radioButtonDistance", "type": "BransonRadioButton", "unnamed": 1, "visible": True}

#pretrigger start: auto
recipeLabWindow_radioButtonAuto_BransonRadioButton = {"checkable": True, "container": uIController_recipeLabWindow_Item, "id": "radioButtonAuto", "type": "BransonRadioButton", "unnamed": 1, "visible": True}




#afterburst tab
subrecipeTabBar_BransonTabButton = {"checkable": True, "container": recipeLabWindow_subrecipeTabBar_TabBar, "occurrence": 2, "type": "BransonTabButton", "unnamed": 1, "visible": True}

#afterburst card enable
recipeLabWindow_afterburstSwitch_BransonSwitch = {"checkable": True, "container": uIController_recipeLabWindow_Item, "id": "afterburstSwitch", "type": "BransonSwitch", "unnamed": 1, "visible": True}

#afterburst:afterburst time
recipeLabWindow_AFTERBURST_TIME_Text = {"container": uIController_recipeLabWindow_Item, "text": "AFTERBURST TIME", "type": "Text", "unnamed": 1, "visible": True}

#afterburst:afterburst amplitude
recipeLabWindow_AFTERBURST_AMPLITUDE_Text = {"container": uIController_recipeLabWindow_Item, "text": "AFTERBURST AMPLITUDE", "type": "Text", "unnamed": 1, "visible": True}

#afterburst:afterburst delay
recipeLabWindow_AFTERBURST_DELAY_Text = {"container": uIController_recipeLabWindow_Item, "text": "AFTERBURST DELAY", "type": "Text", "unnamed": 1, "visible": True}



