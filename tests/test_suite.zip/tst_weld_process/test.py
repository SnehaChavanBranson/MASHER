from screens import login, recipe, recipe_weld_process
import squish

# USERNAME = "ADMIN"
# PASSWORD = "Emerson@1"
#
# filepath = "/home/branson/login_recipe/shared/testdata/"
# dataset = testData.dataset(f"{filepath}/recipe.csv")


# def pre_condition():
#     login.LoginWithCredentials(USERNAME, PASSWORD)
#     test.log("System logged in successfully!")
#     if object.exists(names.imageCross_Image):
#         login.notification_reset()


def reset_notification():
    squish.snooze(0.2)
    test.log("Reset notification function execution")
    login.notification_reset()

def new_create_recipe():
    test.log("Started with creation of new recipe")
    recipe.CreateNewRecipe()
    
def post_condition():
    test.log("proceding for logout function")
    login.logout()

def test_weld_process_amplitude():
    recipe_weld_process.weldProcessTab()
    squish.snooze(0.2)
    recipe_weld_process.pretriggerTab()
    squish.snooze(0.2)
    
    #works for both enable and disable need to test more on this object.

    recipe_weld_process.pretriggerEnable()
    squish.snooze(0.2)
    recipe_weld_process.pretriggerAmplitudeValueEnter()
    squish.snooze(0.2)
    recipe.ClearNumberPad()
    squish.snooze(0.2)
    recipe.enterValue("10")
    squish.snooze(0.2)
    recipe.DoneButton()
    squish.snooze(0.2)

def test_pretrigger_start_distance():
    recipe_weld_process.pretriggerStart_distance_radioButton()
    squish.snooze(0.2)
    recipe_weld_process.pretriggerDistanceValueEnter()
    squish.snooze(0.2)
    recipe.ClearNumberPad()
    squish.snooze(0.2)
    recipe.enterValue("4")
    squish.snooze(0.2)
    recipe.DoneButton()

def test_pretrigger_start_time():
    recipe_weld_process.pretriggerStart_time_radioButton()
    squish.snooze(0.2)
    recipe_weld_process.pretriggerTimeValueEnter()
    squish.snooze(0.2)
    recipe.ClearNumberPad()
    squish.snooze(0.2)
    recipe.enterValue("4")
    squish.snooze(0.2)
    recipe.DoneButton()

def test_afterburst_time():
    recipe_weld_process.afterburstTimeValueEnter()
    recipe.ClearNumberPad()
    squish.snooze(0.2)
    recipe.enterValue("2")
    squish.snooze(0.2)
    recipe.DoneButton()
    
def test_afterburst_delay():
    
    recipe_weld_process.afterburstDelayValueEnter()
    recipe.ClearNumberPad()
    squish.snooze(0.2)
    recipe.enterValue("2")
    squish.snooze(0.2)
    recipe.DoneButton()
    
def test_afterburst_amplitude():
    recipe_weld_process.weldProcessTab()
    recipe_weld_process.afterBurstTab()
    recipe_weld_process.afterBurstEnable()
    recipe_weld_process.afterburstAmplitudeValueEnter()
    recipe.ClearNumberPad()
    squish.snooze(0.2)
    recipe.enterValue("10")
    squish.snooze(0.2)
    recipe.DoneButton()
    

def main():
    test.log("Enters into main function of weld process")
    
    # pre_condition()
    startApplication("QT_UIController")
    squish.snooze(7)
    # reset_notification()
    new_create_recipe()
    # test_weld_process_amplitude()
    # test_pretrigger_start_distance()
    # test_pretrigger_start_time()
    # test_afterburst_amplitude()
    test_afterburst_delay()
    test_afterburst_time()

    
    
    
    