# -*- coding: utf-8 -*-

import names


def main():
    startApplication("QT_UIController")
    mouseClick(waitForObject(names.uIController_backGround_Rectangle), 237, 33, Qt.AltModifier, Qt.LeftButton)
    mouseClick(waitForObject(names.uIController_imageLeftMenu_Image), 17, 14, Qt.AltModifier, Qt.LeftButton)
    mouseClick(waitForObject(names.uIController_RECIPES_Text), Qt.AltModifier, Qt.LeftButton)
    mouseClick(waitForObject(names.recipeSwipeView_creatingImage_Image), 20, 27, Qt.AltModifier, Qt.LeftButton)
    mouseClick(waitForObject(names.recipeTabBar_BransonTabButton_2), 39, 16, Qt.AltModifier, Qt.LeftButton)
    mouseClick(waitForObject(names.subrecipeTabBar_BransonTabButton), 36, 26, Qt.AltModifier, Qt.LeftButton)
    mouseClick(waitForObject(names.recipeLabWindow_controlSwitch_BransonSwitch), 81, 26, Qt.AltModifier, Qt.LeftButton)
    mouseClick(waitForObject(names.recipeLabWindow_switchControl_BransonSwitch), 80, 3, Qt.AltModifier, Qt.LeftButton)
    mouseClick(waitForObject(names.recipeLabWindow_switchControl_BransonSwitch_2), 84, 18, Qt.AltModifier, Qt.LeftButton)
